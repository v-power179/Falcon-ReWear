from odoo import http
from odoo.http import request

class RewearUserWebsite(http.Controller):

    @http.route('/rewear/signup', type='http', auth='public', website=True)
    def rewear_signup_page(self, **kwargs):
        return request.render("your_module_name.rewear_signup_template", {})

    @http.route('/rewear/signup/submit', type='http', auth='public', website=True, csrf=True)
    def rewear_signup_submit(self, **post):
        # Create rewear.user record
        user = request.env['rewear.user'].sudo().create({
            'name': post.get('name'),
            'email': post.get('email'),
            'password': post.get('password'),
            'phone': post.get('phone'),
            'city': post.get('city'),
            'gender': post.get('gender'),
            'country': post.get('country'),
        })

        # Redirect to login page after signup
        return request.redirect('/web/login')
    
    @http.route('/rewear/signup', type='http', auth="public", website=True)
    def rewear_signup_page(self, **kw):
        return request.render("cloth_exchange.rewear_signup_template") 