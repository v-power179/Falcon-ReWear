from odoo import http
from odoo.http import request

class RewearWebsiteController(http.Controller):



    @http.route('/rewear/item', type='http', auth='public', website=True)
    def rewear_home(self, **kw):
        items = request.env['rewear.item'].sudo().search([('is_active', '=', True)], limit=8)
        categories = ['Men', 'Women', 'Kids']
        return request.render('cloth_exchange.rewear_homepage_template', {
            'items': items,
            'categories': categories,
        })

    @http.route(['/rewear/item/<int:item_id>'], type='http', auth='public', website=True)
    def rewear_item_detail(self, item_id):
        item = request.env['rewear.item'].sudo().browse(item_id)
        if not item.exists():
            return request.not_found()

        optional_items = request.env['rewear.item'].sudo().search([
            ('id', '!=', item.id),
            ('category', '=', item.category),
            ('is_active', '=', True)
        ], limit=4)

        return request.render('cloth_exchange.rewear_item_detail_template', {
            'item': item,
            'optional_items': optional_items
        })
