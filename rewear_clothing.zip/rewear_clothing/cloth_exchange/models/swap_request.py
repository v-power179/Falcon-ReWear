from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

class SwapRequest(models.Model):
    _name = 'rewear.swap.request'
    _description = 'Swap Request'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'create_date desc'

    name = fields.Char(string="Request Reference", readonly=True, default='New')
    item_id = fields.Many2one('rewear.item', string="Item", required=True, tracking=True)

    request_type = fields.Selection([
        ('direct', 'Direct Swap'),
        ('points', 'Redeem via Points'),
    ], string="Request Type", required=True, tracking=True)

    points_required = fields.Integer(string="Points Required", readonly=True, tracking=True)

    requester_id = fields.Many2one(
        'res.partner', string="Requested By", required=True,
        tracking=True, default=lambda self: self.env.user.partner_id
    )

    status = fields.Selection([
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
        ('completed', 'Completed')
    ], default='pending', string="Status", tracking=True)

    @api.model
    def create(self, vals):
        # Auto-generate request name
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('rewear.swap.request') or 'New'

        # Auto-fill request_type from item if not given
        if not vals.get('request_type') and vals.get('item_id'):
            item = self.env['rewear.item'].browse(vals['item_id'])
            if item.exchange_mode in ['direct', 'points']:
                vals['request_type'] = item.exchange_mode
            else:
                raise ValidationError(
                    _("Invalid exchange mode '%s' for item '%s'. Allowed: direct, points.") %
                    (item.exchange_mode, item.name)
                )

        return super().create(vals)


    @api.onchange('item_id')
    def _onchange_item(self):
        if self.item_id:
            allowed_modes = dict(self._fields['request_type'].selection).keys()
            mode = self.item_id.exchange_mode
            if mode in allowed_modes:
                self.request_type = mode
            else:
                self.request_type = False
                raise ValidationError(
                    _(f"Invalid exchange mode '{mode}' for item '{self.item_id.name}'. Allowed: {', '.join(allowed_modes)}")
                )
            self.points_required = self.item_id.points_required

    @api.constrains('item_id')
    def _check_item_status(self):
        for rec in self:
            if rec.item_id.status not in ['available', 'requested']:
                raise ValidationError(_("Item '%s' is not available for swap.") % rec.item_id.name)

    def action_approve(self):
        for rec in self:
            rec.status = 'approved'
            rec.item_id.status = 'requested'
            rec.message_post(body=_("Swap request approved for item: %s") % rec.item_id.name)

    def action_reject(self):
        for rec in self:
            rec.status = 'rejected'
            rec.message_post(body=_("Swap request rejected for item: %s") % rec.item_id.name)

    def action_complete(self):
        for rec in self:
            rec.status = 'completed'
            rec.item_id.status = 'swapped' if rec.request_type == 'direct' else 'redeemed'
            rec.item_id.is_active = False
            rec.message_post(body=_("Swap completed. Item marked as %s") % rec.item_id.status)