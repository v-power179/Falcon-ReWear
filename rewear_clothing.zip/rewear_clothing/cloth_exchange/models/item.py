from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

class RewearItem(models.Model):
    _name = 'rewear.item'
    _description = 'ReWear Item'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'create_date desc'
    _rec_name = 'name'

    name = fields.Char(string="Title", required=True, tracking=True)
    item_code = fields.Char(string="Item Code", readonly=True, copy=False, default='New')

    description = fields.Text(string="Description")

    category = fields.Selection([
        ('men', 'Men'),
        ('women', 'Women'),
        ('kids', 'Kids')
    ], string="Category", required=True, tracking=True)

    type = fields.Selection([
        ('top', 'Top'),
        ('bottom', 'Bottom'),   
        ('accessory', 'Accessory')
    ], string="Clothing Type", tracking=True)

    size = fields.Selection([
        ('xs', 'XS'), ('s', 'S'), ('m', 'M'),
        ('l', 'L'), ('xl', 'XL'), ('xxl', 'XXL')
    ], string="Size", tracking=True)

    condition = fields.Selection([
        ('new', 'New'),
        ('used', 'Gently Used')
    ], string="Condition", tracking=True)



    status = fields.Selection([
        ('available', 'Available'),
        ('requested', 'Requested'),
        ('redeemed', 'Redeemed'),
        ('swapped', 'Swapped'),
        ('unavailable', 'Unavailable')
    ], default='available', string="Status", tracking=True)

    points_required = fields.Integer(string="Points Required", default=10, tracking=True)

    exchange_mode = fields.Selection([
        ('direct', 'Direct Swap'),
        ('points', 'Redeem via Points')
    ], string="Exchange Mode", default='points', required=True, tracking=True)

    owner_id = fields.Many2one('res.partner', string="Item Owner", tracking=True)
    is_active = fields.Boolean(string="Active", default=True)

    @api.model
    def create(self, vals):
        if vals.get('item_code', 'New') == 'New':
            vals['item_code'] = self.env['ir.sequence'].next_by_code('rewear.item') or 'New'
        return super().create(vals)

    @api.constrains('points_required')
    def _check_points(self):
        for record in self:
            if record.points_required < 0:
                raise ValidationError(_("Points must be a positive number."))

    @api.onchange('status')
    def _onchange_status(self):
        if self.status in ['swapped', 'redeemed']:
            self.is_active = False

    def name_get(self):
        return [(record.id, f"[{record.item_code or 'N/A'}] {record.name}") for record in self]

    @api.constrains('exchange_mode')
    def _check_exchange_mode(self):
        for rec in self:
            if rec.exchange_mode not in ['direct', 'points']:
                raise ValidationError(_("Invalid exchange mode: %s") % rec.exchange_mode)
            
